#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/__init__.py
#  Purpose       : __init__.py
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================
"""
CiproSeg: LOSO U-Net segmentation framework (single-GPU, research-grade)

A PyTorch-based framework for Leave-One-Series-Out (LOSO) cross-validation
with U-Net architecture for microscopy image segmentation.
"""

__version__ = "0.1.0"
__author__ = "Manaz Kaleel, Team NexoraLab"
__license__ = "Apache-2.0"

# Core components
from .core.engine import Engine
from .core.trainer import Trainer
from .core.evaluator import Evaluator

# Models
from .models.unet import UNet

# Utilities
from .utils.seed import seed_everything
from .utils.config import load_config

__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__license__",
    # Core
    "Engine",
    "Trainer", 
    "Evaluator",
    # Models
    "UNet",
    # Utils
    "seed_everything",
    "load_config",
]