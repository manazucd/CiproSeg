#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/core/evaluator.py
#  Purpose       : Evaluator
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================

from __future__ import annotations

from typing import Any, Dict, List, Tuple, Optional

import numpy as np
import torch
import torch.nn as nn

from ..data.datasets.ciproseg_ecoli import (
    FrameItem,
    build_index,
    read_image_gray,
    read_mask_01,
    pad_to_patch,
)
from ..metrics.segmentation import evaluate_full_image_numpy
from .hooks import HookList


def tile_positions(h: int, w: int, patch: int, stride: int) -> List[Tuple[int, int]]:
    """
    Deterministic tiling positions (top-left) covering full image.
    Ensures last row/col are included.
    """
    ys = list(range(0, max(1, h - patch + 1), stride))
    xs = list(range(0, max(1, w - patch + 1), stride))
    if ys[-1] != max(0, h - patch):
        ys.append(max(0, h - patch))
    if xs[-1] != max(0, w - patch):
        xs.append(max(0, w - patch))
    return [(x, y) for y in ys for x in xs]


@torch.no_grad()
def predict_full_mask_tiled(
    model: nn.Module,
    img_gray01: np.ndarray,
    patch: int = 256,
    stride: int = 128,
    device: str = "cuda",
) -> np.ndarray:
    """
    Full-image tiled inference with overlap averaging.

    Assumes:
      - img_gray01 is 2D float array (H,W) in [0,1]
      - model outputs logits; sigmoid is applied here
    """
    model.eval()

    if img_gray01.ndim != 2:
        raise ValueError(f"img_gray01 must be 2D (H,W), got {img_gray01.shape}")

    h, w = img_gray01.shape
    acc = np.zeros((h, w), dtype=np.float32)
    wgt = np.zeros((h, w), dtype=np.float32)

    positions = tile_positions(h, w, patch, stride)
    for (x, y) in positions:
        patch_img = img_gray01[y:y + patch, x:x + patch]

        # pad to patch if needed (reflect pad for image)
        if patch_img.shape != (patch, patch):
            patch_img, _ = pad_to_patch(
                patch_img,
                np.zeros_like(patch_img, dtype=np.uint8),
                patch,
            )

        inp = torch.from_numpy(patch_img.astype(np.float32)).unsqueeze(0).unsqueeze(0).to(device)
        logits = model(inp)
        prob = torch.sigmoid(logits).squeeze().detach().cpu().numpy().astype(np.float32)

        # Trim if padded beyond image boundary
        ph = min(patch, h - y)
        pw = min(patch, w - x)
        acc[y:y + ph, x:x + pw] += prob[:ph, :pw]
        wgt[y:y + ph, x:x + pw] += 1.0

    wgt = np.maximum(wgt, 1e-8)
    return acc / wgt


@torch.no_grad()
def evaluate_series_full(
    model: nn.Module,
    frames: List[FrameItem],
    patch: int,
    stride: int,
    device: str,
    thr: float = 0.5,
) -> Dict[str, float]:
    """
    Full-image evaluation across a list of frames.
    Runs tiled inference per frame then averages metrics.
    """
    if not frames:
        return {"dice": 0.0, "iou": 0.0, "precision": 0.0, "recall": 0.0}

    dices, ious, precs, recs = [], [], [], []
    for it in frames:
        img = read_image_gray(it.img_path)
        m = read_mask_01(it.mask_path)
        prob = predict_full_mask_tiled(model, img, patch=patch, stride=stride, device=device)
        met = evaluate_full_image_numpy(prob, m, thr=thr)

        dices.append(met["dice"])
        ious.append(met["iou"])
        precs.append(met["precision"])
        recs.append(met["recall"])

    return {
        "dice": float(np.mean(dices)),
        "iou": float(np.mean(ious)),
        "precision": float(np.mean(precs)),
        "recall": float(np.mean(recs)),
    }


class Evaluator:
    """
    Minimal Evaluator API expected by Engine.

    Note:
      - For CiproSeg, the *real* evaluation happens inside Trainer as part of LOSO.
      - Here we provide dataset inspection stats so Engine.evaluate/test won't break.
      - Later, you can wire this to load a checkpoint + run full inference if desired.
    """

    def __init__(self, cfg: Dict[str, Any], datamodule: Any = None, hooks: Optional[HookList] = None):
        self.cfg = cfg
        self.datamodule = datamodule
        self.hooks = hooks or HookList([])
        self.dataset_root = cfg["dataset"]["root"]

    def evaluate(self) -> Dict[str, float]:
        index = build_index(self.dataset_root)
        n_series = len(index)
        n_frames = sum(len(v) for v in index.values())
        return {"num_series": float(n_series), "num_frames": float(n_frames)}

    def test(self) -> Dict[str, float]:
        return self.evaluate()
