#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/core/trainer.py
#  Purpose       : Trainer
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================

from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from ..models.unet import UNet
from ..optim.optimizers import build_optimizer
from ..optim.schedulers import build_scheduler, SchedulerBundle
from ..utils.seed import seed_everything
from ..utils.checkpoint import Checkpointer
from ..data.collate import segmentation_collate_fn
from ..data.datasets.ciproseg_ecoli import (
    build_index,
    make_loso_folds,
    build_fold_splits,
    RandomCropSegDataset,
    default_crops_per_frame,
)
from .evaluator import evaluate_series_full
from .hooks import HookList


class Trainer:
    """
    LOSO single-GPU trainer for CiproSeg.

    Engine expects:
      - Trainer(cfg, datamodule, hooks=?)
      - .train(start_state=...)
      - .best_metric attribute (for checkpointing)
    """

    def __init__(self, cfg: Dict[str, Any], datamodule: Any = None, hooks: Optional[HookList] = None):
        self.cfg = cfg
        self.datamodule = datamodule
        self.hooks = hooks or HookList([])
        self.ckpt = Checkpointer(cfg)

        # ---- config ----
        self.dataset_root = cfg["dataset"]["root"]
        self.train_frac = float(cfg["dataset"].get("train_frac", 0.8))
        self.patch = int(cfg["dataset"].get("patch", 256))
        self.stride = int(cfg["dataset"].get("stride", 128))

        tcfg = cfg.get("trainer", {})
        self.epochs = int(tcfg.get("epochs", 40))
        self.batch_size = int(tcfg.get("batch_size", 8))
        self.num_workers = int(tcfg.get("num_workers", 2))
        self.seed = int(tcfg.get("seed", 1234))
        self.thr = float(tcfg.get("thr", 0.5))
        self.target_patches_per_epoch = int(tcfg.get("target_patches_per_epoch", 2000))

        self.deterministic = bool(tcfg.get("deterministic", False))
        self.benchmark = bool(tcfg.get("benchmark", True))

        force_cpu = bool(tcfg.get("cpu", False))
        self.device = "cuda" if (torch.cuda.is_available() and not force_cpu) else "cpu"

        if self.patch % 16 != 0:
            raise ValueError("patch must be divisible by 16 for 4 pooling steps U-Net.")

        # ---- outputs expected by Engine/Checkpointer ----
        self.best_metric: float = float("-inf")
        self.last_metrics: Dict[str, float] = {}
        self.fold_results: List[Dict[str, Any]] = []

    def train(self, start_state: Optional[Dict[str, Any]] = None) -> None:
        _ = start_state

        index = build_index(self.dataset_root)
        folds = make_loso_folds(index)

        all_fold_test: List[Dict[str, float]] = []
        global_best_val = float("-inf")
        self.fold_results = []

        for fold_id, (test_s, train_s) in enumerate(folds, start=1):
            fold_name = f"fold{fold_id:02d}_test_{test_s}"

            train_frames, val_frames, test_frames = build_fold_splits(
                index=index,
                test_series=test_s,
                train_series=train_s,
                train_frac=self.train_frac,
            )

            fold_seed = self.seed + 1000 * fold_id
            seed_everything(fold_seed, deterministic=self.deterministic, benchmark=self.benchmark)

            model = UNet(in_channels=1, out_channels=1).to(self.device)
            criterion = nn.BCEWithLogitsLoss()

            K = default_crops_per_frame(
                num_train_frames=len(train_frames),
                target_patches_per_epoch=self.target_patches_per_epoch,
                kmin=4,
                kmax=32,
            )
            train_ds = RandomCropSegDataset(
                frames=train_frames,
                patch=self.patch,
                crops_per_frame=K,
                fg_frac=0.01,
                mode_probs=(0.6, 0.3, 0.1),
                do_augment=True,
                return_meta=True,  # safe because collate keeps meta as list
            )

            train_loader = DataLoader(
                train_ds,
                batch_size=self.batch_size,
                shuffle=True,
                num_workers=self.num_workers,
                pin_memory=(self.device == "cuda"),
                collate_fn=segmentation_collate_fn,  # <-- IMPORTANT
            )

            opt = build_optimizer(model, self.cfg)
            sched_bundle: Optional[SchedulerBundle] = build_scheduler(
                opt,
                self.cfg,
                steps_per_epoch=len(train_loader),
                epochs=self.epochs,
            )

            state: Dict[str, Any] = {
                "fold_id": fold_id,
                "fold_name": fold_name,
                "test_series": test_s,
                "n_train": len(train_frames),
                "n_val": len(val_frames),
                "n_test": len(test_frames),
                "patch": self.patch,
                "stride": self.stride,
                "epochs": self.epochs,
                "batch_size": self.batch_size,
                "device": self.device,
                "optim": (self.cfg.get("optim", {}) or {}),
                "sched": (self.cfg.get("sched", {}) or {}),
            }
            self.hooks.on_fold_start(state)

            best_val_dice = float("-inf")
            best_state: Optional[Dict[str, torch.Tensor]] = None

            for ep in range(1, self.epochs + 1):
                state["epoch"] = ep
                self.hooks.on_epoch_start(state)

                model.train()
                running_loss = 0.0

                for batch in train_loader:
                    self.hooks.on_batch_start(state)

                    xb = batch["x"].to(self.device, non_blocking=True)
                    yb = batch["y"].to(self.device, non_blocking=True)

                    opt.zero_grad(set_to_none=True)
                    logits = model(xb)
                    loss = criterion(logits, yb)
                    loss.backward()
                    opt.step()

                    if sched_bundle is not None and sched_bundle.interval == "step":
                        sched_bundle.scheduler.step()

                    running_loss += float(loss.detach().cpu())
                    self.hooks.on_batch_end(state)

                if sched_bundle is not None and sched_bundle.interval == "epoch":
                    sched_bundle.scheduler.step()

                train_loss = running_loss / max(1, len(train_loader))

                val_metrics = evaluate_series_full(
                    model,
                    val_frames,
                    patch=self.patch,
                    stride=self.stride,
                    device=self.device,
                    thr=self.thr,
                )
                val_dice = float(val_metrics["dice"])

                state["train_loss"] = train_loss
                state["val_metrics"] = val_metrics
                state["lr"] = float(opt.param_groups[0].get("lr", 0.0))

                if val_dice > best_val_dice:
                    best_val_dice = val_dice
                    best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

                state["best_val_metric"] = best_val_dice
                self.hooks.on_epoch_end(state)

            if best_state is not None:
                model.load_state_dict(best_state)

            test_metrics = evaluate_series_full(
                model,
                test_frames,
                patch=self.patch,
                stride=self.stride,
                device=self.device,
                thr=self.thr,
            )
            state["test_metrics"] = test_metrics
            self.hooks.on_fold_end(state)

            sched_state = None
            if sched_bundle is not None:
                try:
                    sched_state = sched_bundle.scheduler.state_dict()
                except Exception:
                    sched_state = None

            self.ckpt.save_fold_best(
                fold_id=fold_id,
                fold_name=fold_name,
                model=model,
                optimizer=opt,
                scheduler_state=sched_state,
                best_val_metric=best_val_dice,
                extra={
                    "fold_seed": fold_seed,
                    "test_metrics": test_metrics,
                    "val_best_metrics": {"dice": best_val_dice},
                },
            )

            self.fold_results.append(
                {
                    "fold_id": fold_id,
                    "fold_name": fold_name,
                    "test_series": test_s,
                    "best_val_dice": float(best_val_dice),
                    "test_metrics": test_metrics,
                }
            )

            all_fold_test.append(test_metrics)
            global_best_val = max(global_best_val, best_val_dice)

        self.best_metric = float(global_best_val)

        if all_fold_test:
            self.last_metrics = {
                k: float(np.mean([m[k] for m in all_fold_test]))
                for k in ["dice", "iou", "precision", "recall"]
            }
        else:
            self.last_metrics = {"dice": 0.0, "iou": 0.0, "precision": 0.0, "recall": 0.0}

        self.ckpt.save_run_summary(self, metric_value=self.best_metric)
