#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/core/hooks.py
#  Purpose       : Hook
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================
"""
Description:
    Basic hook interfaces to extend training lifecycle.

    This file is framework/core-level and should NOT contain task logic
    (no dataset splitting, no metrics computation, no model code).

    Hooks receive a mutable `state` dict from Trainer/Evaluator containing
    fields like:
        epoch, fold_id, fold_name, train_loss, val_metrics, test_metrics, ...
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional


class Hook:
    # ---- training lifecycle ----
    def on_train_start(self, state: Dict[str, Any]) -> None:
        ...

    def on_train_end(self, state: Dict[str, Any]) -> None:
        ...

    # ---- fold lifecycle (for LOSO / CV) ----
    def on_fold_start(self, state: Dict[str, Any]) -> None:
        ...

    def on_fold_end(self, state: Dict[str, Any]) -> None:
        ...

    # ---- epoch lifecycle ----
    def on_epoch_start(self, state: Dict[str, Any]) -> None:
        ...

    def on_epoch_end(self, state: Dict[str, Any]) -> None:
        ...

    # ---- batch lifecycle ----
    def on_batch_start(self, state: Dict[str, Any]) -> None:
        ...

    def on_batch_end(self, state: Dict[str, Any]) -> None:
        ...

    # ---- evaluation lifecycle (optional) ----
    def on_eval_start(self, state: Dict[str, Any]) -> None:
        ...

    def on_eval_end(self, state: Dict[str, Any]) -> None:
        ...


class HookList(Hook):
    """
    A simple aggregator that calls each hook in order.
    Trainer/Evaluator can accept HookList and call its methods once.
    """
    def __init__(self, hooks: Optional[List[Hook]] = None):
        self.hooks: List[Hook] = hooks or []

    def on_train_start(self, state: Dict[str, Any]) -> None:
        for h in self.hooks:
            h.on_train_start(state)

    def on_train_end(self, state: Dict[str, Any]) -> None:
        for h in self.hooks:
            h.on_train_end(state)

    def on_fold_start(self, state: Dict[str, Any]) -> None:
        for h in self.hooks:
            h.on_fold_start(state)

    def on_fold_end(self, state: Dict[str, Any]) -> None:
        for h in self.hooks:
            h.on_fold_end(state)

    def on_epoch_start(self, state: Dict[str, Any]) -> None:
        for h in self.hooks:
            h.on_epoch_start(state)

    def on_epoch_end(self, state: Dict[str, Any]) -> None:
        for h in self.hooks:
            h.on_epoch_end(state)

    def on_batch_start(self, state: Dict[str, Any]) -> None:
        for h in self.hooks:
            h.on_batch_start(state)

    def on_batch_end(self, state: Dict[str, Any]) -> None:
        for h in self.hooks:
            h.on_batch_end(state)

    def on_eval_start(self, state: Dict[str, Any]) -> None:
        for h in self.hooks:
            h.on_eval_start(state)

    def on_eval_end(self, state: Dict[str, Any]) -> None:
        for h in self.hooks:
            h.on_eval_end(state)
