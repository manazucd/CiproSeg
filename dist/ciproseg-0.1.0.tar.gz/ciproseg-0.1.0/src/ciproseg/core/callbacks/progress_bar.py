#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/core/callbacks/progress_bar.py
#  Purpose       : Progress bar for printing
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================
from __future__ import annotations

from ..hooks import Hook
from ...utils.dist import is_global_zero


def _fmt(x, nd=4):
    try:
        return f"{float(x):.{nd}f}"
    except Exception:
        return "nan"


class ProgressBar(Hook):
    """
    Framework-friendly progress printer.

    IMPORTANT:
    - This should contain only printing/logging.
    - No dataset/model/metric computations here.
    - It relies on Trainer/Evaluator to populate `state`.
    """

    def on_train_start(self, state):
        if is_global_zero():
            print("[PB] Training started")

    def on_fold_start(self, state):
        if not is_global_zero():
            return

        fold_id = state.get("fold_id", None)
        fold_name = state.get("fold_name", "")
        test_series = state.get("test_series", "")

        n_train = state.get("n_train", None)
        n_val = state.get("n_val", None)
        n_test = state.get("n_test", None)

        patch = state.get("patch", None)
        stride = state.get("stride", None)
        epochs = state.get("epochs", None)
        batch_size = state.get("batch_size", None)
        lr = state.get("lr", None)

        print("\n====================")
        if fold_id is not None:
            print(f"[PB] Fold {fold_id:02d} | {fold_name} | test_series={test_series}")
        else:
            print(f"[PB] Fold | {fold_name} | test_series={test_series}")

        if (n_train is not None) or (n_val is not None) or (n_test is not None):
            print(f"[PB] frames: train={n_train} | val={n_val} | test={n_test}")

        if patch is not None:
            print(f"[PB] patch={patch} stride={stride} epochs={epochs} batch={batch_size} lr={lr}")
        print("====================")

    def on_epoch_end(self, state):
        if not is_global_zero():
            return

        ep = state.get("epoch", 0)
        fold_name = state.get("fold_name", "")

        train_loss = state.get("train_loss", None)
        val_metrics = state.get("val_metrics", {}) or {}
        best_val = state.get("best_val_metric", None)

        val_dice = val_metrics.get("dice", None)
        val_iou = val_metrics.get("iou", None)

        msg = (
            f"[PB] {fold_name} | ep {int(ep):03d} | "
            f"train_loss = {_fmt(train_loss, nd=5)} | "
            f"val_dice = {_fmt(val_dice)} | val_iou = {_fmt(val_iou)}"
        )
        if best_val is not None:
            msg += f" | best_val_dice = {_fmt(best_val)}"

        print(msg)

    def on_fold_end(self, state):
        if not is_global_zero():
            return

        fold_name = state.get("fold_name", "")
        test_metrics = state.get("test_metrics", {}) or {}

        print(
            f"[PB] {fold_name} | < TEST >| "
            f"dice = {_fmt(test_metrics.get('dice'))} | "
            f"iou = {_fmt(test_metrics.get('iou'))} | "
            f"prec = {_fmt(test_metrics.get('precision'))} | "
            f"rec = {_fmt(test_metrics.get('recall'))}"
        )

    def on_train_end(self, state):
        if is_global_zero():
            print("[PB] Training finished")
