#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/visualization/plot_curves.py
#  Purpose       : Plot
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple, Union

import matplotlib.pyplot as plt


# -----------------------------
# Data containers
# -----------------------------
@dataclass(frozen=True)
class Curve:
    name: str
    x: List[float]
    y: List[float]


@dataclass(frozen=True)
class FoldCurves:
    fold_name: str
    curves: Dict[str, Curve]  # key: curve name


# -----------------------------
# Parsing helpers
# -----------------------------
_METRIC_PATTERNS = [
    # examples:
    #  "train_loss=0.12345"
    #  "val_dice=0.8123"
    #  "val_iou=0.7123"
    #  "lr=1e-4"
    re.compile(r"(?P<key>[a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*(?P<val>[-+0-9.eE]+)")
]

_EPOCH_PATTERN = re.compile(r"\bEpoch\s+(?P<epoch>\d+)\b", re.IGNORECASE)


def _safe_float(s: str) -> Optional[float]:
    try:
        return float(s)
    except Exception:
        return None


def parse_metrics_from_line(line: str) -> Dict[str, float]:
    """
    Extract key=value numeric tokens from a log line.

    Returns:
        dict like {"train_loss": 0.12, "val_dice": 0.81, ...}
    """
    out: Dict[str, float] = {}
    for pat in _METRIC_PATTERNS:
        for m in pat.finditer(line):
            key = m.group("key")
            val = _safe_float(m.group("val"))
            if val is not None:
                out[key] = val
    return out


def parse_epoch_from_line(line: str) -> Optional[int]:
    m = _EPOCH_PATTERN.search(line)
    if not m:
        return None
    try:
        return int(m.group("epoch"))
    except Exception:
        return None


def parse_fold_from_line(line: str) -> Optional[str]:
    """
    Try to infer fold name from log line.

    We support common patterns:
      - "[fold01_test_X] Epoch ..."
      - "Fold: fold01_test_X"
      - "fold01_test_X | ..."
    """
    # bracket prefix like [fold01_test_ABC]
    m = re.search(r"\[(fold\d+_test_[^\]]+)\]", line)
    if m:
        return m.group(1)

    # "Fold: fold01_test_ABC"
    m = re.search(r"\bFold:\s*(fold\d+_test_[A-Za-z0-9_-]+)", line)
    if m:
        return m.group(1)

    # "fold01_test_ABC | dice=..."
    m = re.search(r"\b(fold\d+_test_[A-Za-z0-9_-]+)\b", line)
    if m:
        return m.group(1)

    return None


# -----------------------------
# High-level log readers
# -----------------------------
def read_training_log(
    path: str,
    keys: Sequence[str] = ("train_loss", "val_dice", "val_iou", "lr"),
    *,
    strict_epoch: bool = False,
) -> List[FoldCurves]:
    """
    Parse a text log file and return curves per fold.

    This expects your Trainer/ProgressBar/logger to emit lines containing:
      - "Epoch <int>"
      - metric tokens like "train_loss=...", "val_dice=...", etc.
      - optionally a fold name in bracket prefix: "[fold01_test_X] ..."

    Args:
        path: log file path
        keys: which metric keys to capture
        strict_epoch: if True, only record metrics on lines that contain "Epoch N".

    Returns:
        list of FoldCurves (one per fold_name detected).
    """
    if not os.path.exists(path):
        raise FileNotFoundError(path)

    # fold -> metric -> (epoch list, value list)
    store: Dict[str, Dict[str, Tuple[List[float], List[float]]]] = {}
    last_fold: Optional[str] = None

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            fold = parse_fold_from_line(line) or last_fold
            if fold is not None:
                last_fold = fold

            epoch = parse_epoch_from_line(line)
            metrics = parse_metrics_from_line(line)

            if strict_epoch and epoch is None:
                continue

            # record only selected keys
            for k in keys:
                if k not in metrics:
                    continue
                if fold is None:
                    # If fold not detectable, group into a generic bucket
                    fold = "fold_unknown"
                store.setdefault(fold, {}).setdefault(k, ([], []))
                xs, ys = store[fold][k]
                # If epoch is missing, use monotonically increasing x
                xval = float(epoch) if epoch is not None else float(len(xs) + 1)
                xs.append(xval)
                ys.append(float(metrics[k]))

    out: List[FoldCurves] = []
    for fold_name, metric_map in sorted(store.items(), key=lambda kv: kv[0]):
        curves: Dict[str, Curve] = {}
        for k, (xs, ys) in metric_map.items():
            curves[k] = Curve(name=k, x=xs, y=ys)
        out.append(FoldCurves(fold_name=fold_name, curves=curves))
    return out


# -----------------------------
# Plotting
# -----------------------------
def _ensure_dir(path: str) -> None:
    d = os.path.dirname(os.path.abspath(path))
    if d:
        os.makedirs(d, exist_ok=True)


def plot_fold_curves(
    fold_curves: FoldCurves,
    metrics: Sequence[str] = ("train_loss", "val_dice", "val_iou", "lr"),
    *,
    title: Optional[str] = None,
    show: bool = True,
    savepath: Optional[str] = None,
) -> None:
    """
    Plot selected metrics for a single fold.
    """
    present = [m for m in metrics if m in fold_curves.curves]
    if not present:
        raise ValueError(f"No requested metrics found for {fold_curves.fold_name}. Available={list(fold_curves.curves)}")

    plt.figure()
    for m in present:
        c = fold_curves.curves[m]
        plt.plot(c.x, c.y, label=m)
    plt.xlabel("epoch" if all(int(x) == x for x in fold_curves.curves[present[0]].x) else "step")
    plt.ylabel("value")
    plt.title(title or fold_curves.fold_name)
    plt.legend()
    plt.tight_layout()

    if savepath:
        _ensure_dir(savepath)
        plt.savefig(savepath, dpi=150)
    if show:
        plt.show()
    else:
        plt.close()


def plot_metric_across_folds(
    folds: Sequence[FoldCurves],
    metric: str = "val_dice",
    *,
    title: Optional[str] = None,
    show: bool = True,
    savepath: Optional[str] = None,
) -> None:
    """
    Plot one metric across multiple folds on a single figure.
    """
    plt.figure()
    plotted = 0
    for fc in folds:
        if metric not in fc.curves:
            continue
        c = fc.curves[metric]
        plt.plot(c.x, c.y, label=fc.fold_name)
        plotted += 1

    if plotted == 0:
        raise ValueError(f"Metric '{metric}' not found in any fold.")

    plt.xlabel("epoch" if all(int(x) == x for x in folds[0].curves[metric].x) else "step")
    plt.ylabel(metric)
    plt.title(title or f"{metric} across folds")
    plt.legend(fontsize=8, ncol=1)
    plt.tight_layout()

    if savepath:
        _ensure_dir(savepath)
        plt.savefig(savepath, dpi=150)
    if show:
        plt.show()
    else:
        plt.close()


def summarize_best_per_fold(
    folds: Sequence[FoldCurves],
    metric: str = "val_dice",
    mode: str = "max",
) -> Dict[str, float]:
    """
    Return best metric value per fold (and no plotting).

    Args:
        metric: curve name
        mode: "max" (e.g., dice/iou) or "min" (e.g., loss)

    Returns:
        {fold_name: best_value}
    """
    out: Dict[str, float] = {}
    for fc in folds:
        if metric not in fc.curves:
            continue
        vals = fc.curves[metric].y
        if not vals:
            continue
        if mode == "min":
            out[fc.fold_name] = float(min(vals))
        else:
            out[fc.fold_name] = float(max(vals))
    return out


# -----------------------------
# Convenience CLI-like entry
# -----------------------------
def plot_from_logfile(
    logfile: str,
    *,
    keys: Sequence[str] = ("train_loss", "val_dice", "val_iou", "lr"),
    fold: Optional[str] = None,
    metric_across_folds: Optional[str] = None,
    show: bool = True,
    outdir: Optional[str] = None,
) -> List[FoldCurves]:
    """
    One-call helper for notebooks/scripts.

    Examples:
        folds = plot_from_logfile("runs/train.log", fold="fold01_test_A", outdir="runs/plots")
        folds = plot_from_logfile("runs/train.log", metric_across_folds="val_dice")
    """
    folds = read_training_log(logfile, keys=keys, strict_epoch=False)

    if outdir:
        os.makedirs(outdir, exist_ok=True)

    if fold is not None:
        fc = next((x for x in folds if x.fold_name == fold), None)
        if fc is None:
            raise KeyError(f"Fold '{fold}' not found. Available: {[x.fold_name for x in folds]}")
        savepath = os.path.join(outdir, f"{fold}_curves.png") if outdir else None
        plot_fold_curves(fc, metrics=keys, title=fold, show=show, savepath=savepath)

    if metric_across_folds is not None:
        savepath = os.path.join(outdir, f"{metric_across_folds}_across_folds.png") if outdir else None
        plot_metric_across_folds(folds, metric=metric_across_folds, show=show, savepath=savepath)

    return folds
