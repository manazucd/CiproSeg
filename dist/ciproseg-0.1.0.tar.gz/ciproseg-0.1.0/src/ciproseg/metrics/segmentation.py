#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/metrics/segmentation.py
#  Purpose       : segmentation matrices
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================
from __future__ import annotations

from typing import Dict
import numpy as np
import torch


def _confusion_from_probs(
    probs: torch.Tensor, target: torch.Tensor, thr: float = 0.5
):
    pred = (probs >= thr).float()
    target = (target >= 0.5).float()
    tp = (pred * target).sum()
    fp = (pred * (1 - target)).sum()
    fn = ((1 - pred) * target).sum()
    return tp, fp, fn


def dice_from_probs(probs: torch.Tensor, target: torch.Tensor, thr: float = 0.5, eps: float = 1e-8) -> float:
    tp, fp, fn = _confusion_from_probs(probs, target, thr)
    dice = (2 * tp + eps) / (2 * tp + fp + fn + eps)
    return float(dice.detach().cpu())


def iou_from_probs(probs: torch.Tensor, target: torch.Tensor, thr: float = 0.5, eps: float = 1e-8) -> float:
    tp, fp, fn = _confusion_from_probs(probs, target, thr)
    iou = (tp + eps) / (tp + fp + fn + eps)
    return float(iou.detach().cpu())


def precision_from_probs(probs: torch.Tensor, target: torch.Tensor, thr: float = 0.5, eps: float = 1e-8) -> float:
    tp, fp, _ = _confusion_from_probs(probs, target, thr)
    prec = (tp + eps) / (tp + fp + eps)
    return float(prec.detach().cpu())


def recall_from_probs(probs: torch.Tensor, target: torch.Tensor, thr: float = 0.5, eps: float = 1e-8) -> float:
    tp, _, fn = _confusion_from_probs(probs, target, thr)
    rec = (tp + eps) / (tp + fn + eps)
    return float(rec.detach().cpu())


def evaluate_full_image_numpy(prob_map: np.ndarray, mask01: np.ndarray, thr: float = 0.5, eps: float = 1e-8) -> Dict[str, float]:
    """
    Full-image numpy evaluation for tiled inference outputs.

    Args:
        prob_map: float array (H,W) in [0,1]
        mask01: uint8/bool array (H,W) where foreground is >0
        thr: threshold to binarize prob_map
        eps: stability

    Returns:
        {"dice","iou","precision","recall"} as floats
    """
    if prob_map.ndim != 2 or mask01.ndim != 2:
        raise ValueError(f"Expected 2D arrays, got prob_map {prob_map.shape}, mask01 {mask01.shape}")

    pred = (prob_map >= thr).astype(np.uint8)
    gt = (mask01 > 0).astype(np.uint8)

    tp = float((pred & gt).sum())
    fp = float((pred & (1 - gt)).sum())
    fn = float(((1 - pred) & gt).sum())

    dice = (2 * tp + eps) / (2 * tp + fp + fn + eps)
    iou = (tp + eps) / (tp + fp + fn + eps)
    prec = (tp + eps) / (tp + fp + eps)
    rec = (tp + eps) / (tp + fn + eps)

    return {"dice": float(dice), "iou": float(iou), "precision": float(prec), "recall": float(rec)}
