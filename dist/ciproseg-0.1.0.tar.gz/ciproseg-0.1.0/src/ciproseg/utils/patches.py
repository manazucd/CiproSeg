#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/utils/patches.py
#  Purpose       : patches
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================

from __future__ import annotations

from typing import Tuple
import cv2
import numpy as np


def pad_to_patch(img: np.ndarray, mask01: np.ndarray, patch: int) -> Tuple[np.ndarray, np.ndarray]:
    """
    Ensure (img, mask) are at least (patch, patch) by padding.
    Image: reflect padding. Mask: constant 0 padding.

    Returns exactly (patch, patch) slices.
    """
    if img.ndim != 2 or mask01.ndim != 2:
        raise ValueError(f"pad_to_patch expects 2D arrays, got img={img.shape}, mask={mask01.shape}")

    h, w = img.shape
    pad_h = max(0, patch - h)
    pad_w = max(0, patch - w)
    if pad_h == 0 and pad_w == 0:
        return img, mask01

    img_p = cv2.copyMakeBorder(img, 0, pad_h, 0, pad_w, borderType=cv2.BORDER_REFLECT_101)
    m_p = cv2.copyMakeBorder(mask01, 0, pad_h, 0, pad_w, borderType=cv2.BORDER_CONSTANT, value=0)

    return img_p[:patch, :patch], m_p[:patch, :patch]

