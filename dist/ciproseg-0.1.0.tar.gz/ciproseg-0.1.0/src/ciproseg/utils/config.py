#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/utils/config.py
#  Purpose       : Config
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

import yaml


@dataclass(frozen=True)
class ConfigPaths:
    """Commonly-used resolved paths (optional convenience)."""
    config_path: Path
    work_dir: Path
    output_dir: Path


def load_config(path: str) -> Dict[str, Any]:
    """
    Load a YAML config file into a dict.

    Guarantees:
      - returns a dict
      - never returns None
      - raises a helpful error on YAML / IO issues
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Config file not found: {p}")
    if not p.is_file():
        raise ValueError(f"Config path is not a file: {p}")

    try:
        with p.open("r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML in config: {p}") from e

    if cfg is None:
        cfg = {}
    if not isinstance(cfg, dict):
        raise ValueError("Config root must be a mapping (YAML dict).")

    # Light normalization (keep it minimal; don't surprise users)
    cfg.setdefault("trainer", {})
    cfg.setdefault("dataset", {})
    cfg.setdefault("logger", {})

    return cfg


def resolve_paths(cfg: Dict[str, Any], config_path: Optional[str] = None) -> ConfigPaths:
    """
    Compute resolved paths used across the project.
    This is optional, but helps keep path logic out of Engine/Trainer.

    Rules:
      - work_dir defaults to current working directory
      - output_dir defaults to trainer.output_dir or work_dir/'runs'
      - paths are returned as pathlib.Path
    """
    work_dir = Path(cfg.get("trainer", {}).get("work_dir", Path.cwd())).expanduser().resolve()

    output_dir = cfg.get("trainer", {}).get("output_dir", None)
    if output_dir is None or str(output_dir).strip() == "":
        output_dir_path = work_dir / "runs"
    else:
        output_dir_path = Path(output_dir).expanduser()
        if not output_dir_path.is_absolute():
            output_dir_path = (work_dir / output_dir_path)
        output_dir_path = output_dir_path.resolve()

    cfg_path = Path(config_path).expanduser().resolve() if config_path else Path("<memory>")

    return ConfigPaths(config_path=cfg_path, work_dir=work_dir, output_dir=output_dir_path)


