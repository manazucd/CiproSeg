#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/utils/logger.py
#  Purpose       : logger
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

from .dist import is_global_zero

_LOGGER: Optional[logging.Logger] = None


def setup_logging(cfg: Dict[str, Any]) -> None:
    """
    Configure a single project logger.

    Features:
      - console logging always
      - optional file logging to trainer.output_dir / train.log (global-zero only)
      - configurable level via cfg["logger"]["level"] (default INFO)

    Safe to call multiple times: it won't duplicate handlers.
    """
    global _LOGGER

    name = str((cfg.get("logger", {}) or {}).get("name", "ciproseg"))
    level_str = str((cfg.get("logger", {}) or {}).get("level", "INFO")).upper().strip()
    level = getattr(logging, level_str, logging.INFO)

    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.propagate = False  # don't double-log via root

    # Avoid duplicate handlers if setup_logging called repeatedly
    if getattr(logger, "_ciproseg_configured", False):
        _LOGGER = logger
        return

    fmt = str((cfg.get("logger", {}) or {}).get("format", "[%(levelname)s] %(message)s"))
    datefmt = str((cfg.get("logger", {}) or {}).get("datefmt", "%Y-%m-%d %H:%M:%S"))
    formatter = logging.Formatter(fmt=fmt, datefmt=datefmt)

    # Console handler
    ch = logging.StreamHandler()
    ch.setLevel(level)
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # Optional file handler (recommended for experiments)
    log_to_file = bool((cfg.get("logger", {}) or {}).get("to_file", True))
    if log_to_file and is_global_zero():
        out_dir = (cfg.get("trainer", {}) or {}).get("output_dir", "runs")
        out_dir_path = Path(str(out_dir)).expanduser()
        out_dir_path.mkdir(parents=True, exist_ok=True)

        filename = str((cfg.get("logger", {}) or {}).get("filename", "train.log"))
        fh_path = out_dir_path / filename

        fh = logging.FileHandler(str(fh_path), mode="a", encoding="utf-8")
        fh.setLevel(level)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    # Mark configured
    setattr(logger, "_ciproseg_configured", True)

    _LOGGER = logger


def get_logger(cfg: Optional[Dict[str, Any]] = None) -> logging.Logger:
    """
    Retrieve the singleton project logger.
    If not configured yet, configure it with the provided cfg (or defaults).
    """
    global _LOGGER
    if _LOGGER is None:
        setup_logging(cfg or {})
    return _LOGGER

