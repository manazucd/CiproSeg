#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/utils/device.py
#  Purpose       : Device selection
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch

from .dist import is_dist_initialized, get_local_rank


@dataclass(frozen=True)
class DeviceInfo:
    device: torch.device
    device_str: str
    is_cuda: bool
    local_rank: int
    world_size: int


def resolve_device(
    prefer_cuda: bool = True,
    force_cpu: bool = False,
    device: Optional[str] = None,
) -> DeviceInfo:
    """
    Resolve the torch device to use.

    Priority:
      1) explicit `device` argument if provided (e.g. "cuda", "cuda:0", "cpu")
      2) force_cpu=True => cpu
      3) if DDP is initialized => cuda:{local_rank} (if cuda available), else cpu
      4) prefer_cuda and cuda available => cuda
      5) cpu

    Returns:
      DeviceInfo with device + rank metadata (rank info is meaningful only in DDP).
    """
    # Explicit override
    if device is not None:
        dev = torch.device(device)
        return DeviceInfo(
            device=dev,
            device_str=str(dev),
            is_cuda=(dev.type == "cuda"),
            local_rank=get_local_rank(),
            world_size=(torch.distributed.get_world_size() if is_dist_initialized() else 1),
        )

    if force_cpu:
        dev = torch.device("cpu")
        return DeviceInfo(
            device=dev,
            device_str="cpu",
            is_cuda=False,
            local_rank=get_local_rank(),
            world_size=(torch.distributed.get_world_size() if is_dist_initialized() else 1),
        )

    # If DDP is active, prefer cuda:{local_rank}
    if is_dist_initialized():
        lr = get_local_rank()
        if torch.cuda.is_available():
            dev = torch.device(f"cuda:{lr}")
            return DeviceInfo(
                device=dev,
                device_str=str(dev),
                is_cuda=True,
                local_rank=lr,
                world_size=torch.distributed.get_world_size(),
            )
        # DDP but no CUDA (rare)
        dev = torch.device("cpu")
        return DeviceInfo(
            device=dev,
            device_str="cpu",
            is_cuda=False,
            local_rank=lr,
            world_size=torch.distributed.get_world_size(),
        )

    # Normal single-process
    if prefer_cuda and torch.cuda.is_available():
        dev = torch.device("cuda")
        return DeviceInfo(device=dev, device_str="cuda", is_cuda=True, local_rank=0, world_size=1)

    dev = torch.device("cpu")
    return DeviceInfo(device=dev, device_str="cpu", is_cuda=False, local_rank=0, world_size=1)

