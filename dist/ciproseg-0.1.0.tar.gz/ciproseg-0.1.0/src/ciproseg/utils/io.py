#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/utils/io.py
#  Purpose       : I/O
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================

from __future__ import annotations

import contextlib
import io
import logging
import warnings

import numpy as np
import tifffile as tiff


# ------------------------------------------------------------------
# tifffile sometimes emits ImageJ metadata warnings via logging/prints.
# We silence only that known-noisy message; real errors still raise.
# ------------------------------------------------------------------

_NOISY_SUBSTR = "ImageJ series metadata invalid or corrupted file"


@contextlib.contextmanager
def _suppress_tifffile_noise() -> None:
    """
    Suppress tifffile's noisy ImageJ metadata messages.

    This covers:
      - Python warnings
      - tifffile logger messages
      - occasional stderr prints
    """
    # 1) warnings (if they come as warnings)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message=f".*{_NOISY_SUBSTR}.*")

        # 2) logger (tifffile uses logging in some paths)
        tif_logger = logging.getLogger("tifffile")
        prev_level = tif_logger.level
        tif_logger.setLevel(logging.ERROR)

        # 3) stderr prints (some tifffile paths print directly)
        buf = io.StringIO()
        try:
            with contextlib.redirect_stderr(buf):
                yield
        finally:
            tif_logger.setLevel(prev_level)


def _imread_gray_any(path: str) -> np.ndarray:
    """
    Read image from path and return a 2D grayscale numpy array.

    Handles:
      - (H,W)
      - (H,W,C)
      - (C,H,W)

    Raises friendly error if TIFF uses LZW compression and imagecodecs is missing.
    """
    try:
        with _suppress_tifffile_noise():
            img = tiff.imread(path)

    except ValueError as e:
        msg = str(e)
        if "requires the 'imagecodecs' package" in msg:
            raise ValueError(
                f"\nTIFF read failed for: {path}\n"
                "This TIFF appears to use LZW (or similar) compression.\n"
                "Fix:\n"
                "  pip install imagecodecs\n"
                "or\n"
                "  conda install -c conda-forge imagecodecs\n"
            ) from e
        raise

    except Exception as e:
        raise RuntimeError(
            f"Failed to read image: {path} ({type(e).__name__}: {e})"
        ) from e

    # Convert to 2D grayscale if needed
    if img.ndim == 3:
        # channels-last
        if img.shape[-1] in (1, 3, 4):
            img = img[..., 0]
        # channels-first
        elif img.shape[0] in (1, 3, 4):
            img = img[0, ...]
        else:
            img = img[..., 0]

    if img.ndim != 2:
        raise ValueError(
            f"Expected 2D grayscale after conversion, got shape {img.shape} for {path}"
        )

    return img


def read_image_gray(path: str) -> np.ndarray:
    """
    Read image as float32 in [0,1] (best-effort normalization).
    """
    img = _imread_gray_any(path).astype(np.float32)

    if img.size == 0:
        return img

    max_val = float(np.max(img))
    if max_val > 1.0:
        img = img / max_val

    return img


def read_mask_01(path: str) -> np.ndarray:
    """
    Read mask as uint8 values in {0,1}. Any non-zero becomes 1.
    """
    m = _imread_gray_any(path)
    return (m > 0).astype(np.uint8)
