#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/data/collate.py
#  Purpose       : collate
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================

from __future__ import annotations

from typing import Any, Dict, List, Tuple, Union, Optional
import torch

# Dataset items may be:
#   - dict: {"x": Tensor, "y": Tensor, "meta": {...} (optional)}
#   - tuple: (x, y)
BatchItem = Union[Dict[str, Any], Tuple[torch.Tensor, torch.Tensor]]


def default_collate_fn(batch: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
    """
    Framework default: expects each item is a dict with keys 'x' and 'y'.
    Does not handle meta.
    """
    if not batch:
        raise ValueError("Empty batch")
    xs = torch.stack([b["x"] for b in batch], dim=0)
    ys = torch.stack([b["y"] for b in batch], dim=0)
    return {"x": xs, "y": ys}


def segmentation_collate_fn(batch: List[BatchItem]) -> Dict[str, Any]:
    """
    Collate function for segmentation tasks.

    Supports two dataset item formats:
      1) (x, y) tuples where:
          x: (C,H,W) float tensor
          y: (C,H,W) float tensor
      2) dicts with:
          {"x": x, "y": y, "meta": {...} (optional)}

    Returns:
      {"x": (B,C,H,W), "y": (B,C,H,W), "meta": List[dict] (optional)}
    """
    if not batch:
        raise ValueError("Empty batch")

    first = batch[0]

    # Case 1: tuple dataset (x, y)
    if isinstance(first, tuple):
        xs = torch.stack([x for (x, _) in batch], dim=0)  # type: ignore[misc]
        ys = torch.stack([y for (_, y) in batch], dim=0)  # type: ignore[misc]
        return {"x": xs, "y": ys}

    # Case 2: dict dataset {"x","y", optional "meta"}
    if isinstance(first, dict):
        xs = torch.stack([b["x"] for b in batch], dim=0)  # type: ignore[index]
        ys = torch.stack([b["y"] for b in batch], dim=0)  # type: ignore[index]
        out: Dict[str, Any] = {"x": xs, "y": ys}

        # keep meta as a list (do NOT stack)
        if "meta" in first:
            out["meta"] = [b.get("meta", {}) for b in batch]  # type: ignore[union-attr]
        return out

    raise TypeError(f"Unsupported batch item type: {type(first)}")
