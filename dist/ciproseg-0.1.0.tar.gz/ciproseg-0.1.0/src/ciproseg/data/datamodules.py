#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/data/datamodules.py
#  Purpose       : datamodules
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

import torch
from torch.utils.data import DataLoader, Dataset

from .collate import default_collate_fn, segmentation_collate_fn


@dataclass
class DataModule:
    """
    Generic DataModule for standard train/val/test datasets.

    NOTE:
      CiproSeg uses LOSO CV, so you typically will not use a single global
      train/val/test dataset here unless you decide on one held-out series.
    """
    train: Dataset
    val: Optional[Dataset]
    test: Optional[Dataset]
    batch_size: int = 32
    num_workers: int = 4
    pin_memory: bool = True
    collate_fn: Any = default_collate_fn

    def train_dataloader(self) -> DataLoader:
        return DataLoader(
            self.train,
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            shuffle=True,
            pin_memory=self.pin_memory,
            collate_fn=self.collate_fn,
        )

    def val_dataloader(self) -> Optional[DataLoader]:
        if self.val is None:
            return None
        return DataLoader(
            self.val,
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            shuffle=False,
            pin_memory=self.pin_memory,
            collate_fn=self.collate_fn,
        )

    def test_dataloader(self) -> Optional[DataLoader]:
        if self.test is None:
            return None
        return DataLoader(
            self.test,
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            shuffle=False,
            pin_memory=self.pin_memory,
            collate_fn=self.collate_fn,
        )


class CiproSegDataModule:
    """
    Light wrapper for DataLoader settings for CiproSeg.

    Because CiproSeg training uses LOSO folds and per-fold datasets,
    this class is intentionally simple: you pass datasets in (per fold),
    and it returns loaders with the right collate/pin_memory/num_workers.

    This lets Trainer stay clean and prevents hardcoding DataLoader options.
    """

    def __init__(self, cfg: Dict[str, Any], device: str = "cuda"):
        tcfg = cfg.get("trainer", {})
        self.batch_size = int(tcfg.get("batch_size", 8))
        self.num_workers = int(tcfg.get("num_workers", 2))
        self.pin_memory = (device == "cuda")
        self.collate_fn = segmentation_collate_fn

    def make_train_loader(self, train_ds: Dataset) -> DataLoader:
        return DataLoader(
            train_ds,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            collate_fn=self.collate_fn,
        )

    def make_eval_loader(self, ds: Dataset) -> DataLoader:
        # not used right now (you do full-image eval without a loader),
        # but provided for future use (e.g., patch-based validation)
        return DataLoader(
            ds,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            collate_fn=self.collate_fn,
        )


def build_datamodule(cfg: Dict[str, Any]) -> Any:
    """
    Factory used by Engine.

    For CiproSeg LOSO, Trainer does fold construction; Engine can still
    call this so the framework stays consistent. We return a CiproSegDataModule
    wrapper for DataLoader settings.

    If you later add other tasks (classification/regression), you can return
    the generic DataModule or other datamodules here.
    """
    # Determine device the same way trainer does (safe)
    force_cpu = bool(cfg.get("trainer", {}).get("cpu", False))
    device = "cuda" if (torch.cuda.is_available() and not force_cpu) else "cpu"
    return CiproSegDataModule(cfg, device=device)
