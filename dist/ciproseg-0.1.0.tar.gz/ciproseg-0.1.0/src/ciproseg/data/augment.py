#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/data/augment.py
#  Purpose       : augment
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================

from __future__ import annotations

from typing import Tuple
import random

import cv2
import numpy as np


def compute_boundary_map(mask01: np.ndarray, ksize: int = 3) -> np.ndarray:
    """
    Compute a simple boundary map via morphological gradient.
    Returns uint8 {0,1}.
    """
    if mask01.ndim != 2:
        raise ValueError(f"compute_boundary_map expects 2D mask, got {mask01.shape}")

    m = (mask01 > 0).astype(np.uint8) * 255
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ksize, ksize))
    grad = cv2.morphologyEx(m, cv2.MORPH_GRADIENT, kernel)
    return (grad > 0).astype(np.uint8)


def augment_pair(img: np.ndarray, mask01: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """
    Lightweight geometric + photometric augmentation.
    - flips
    - small rotation
    - brightness/contrast jitter
    - gaussian noise
    """
    if random.random() < 0.5:
        img = np.fliplr(img).copy()
        mask01 = np.fliplr(mask01).copy()
    if random.random() < 0.5:
        img = np.flipud(img).copy()
        mask01 = np.flipud(mask01).copy()

    if random.random() < 0.5:
        angle = random.uniform(-15.0, 15.0)
        h, w = img.shape
        M = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), angle, 1.0)
        img = cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT_101)
        mask01 = cv2.warpAffine(
            mask01, M, (w, h),
            flags=cv2.INTER_NEAREST,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=0,
        )

    if random.random() < 0.7:
        alpha = random.uniform(0.9, 1.1)
        beta = random.uniform(-0.05, 0.05)
        img = np.clip(alpha * img + beta, 0.0, 1.0)

    if random.random() < 0.5:
        sigma = random.uniform(0.0, 0.02)
        if sigma > 0:
            noise = np.random.normal(0.0, sigma, size=img.shape).astype(np.float32)
            img = np.clip(img + noise, 0.0, 1.0)

    return img, mask01


def sample_patch_xy(
    mask01: np.ndarray,
    patch: int,
    mode_probs: Tuple[float, float, float] = (0.6, 0.3, 0.1),
    min_fg_frac: float = 0.01,
    max_tries: int = 50,
) -> Tuple[int, int, str]:
    """
    Sample top-left (x,y) for a patch with a mixture of:
      - foreground-biased
      - boundary-biased
      - random
    """
    h, w = mask01.shape[:2]
    if h <= patch or w <= patch:
        return 0, 0, "fallback"

    p_fg, p_bd, _ = mode_probs
    r = random.random()
    if r < p_fg:
        mode = "foreground"
    elif r < p_fg + p_bd:
        mode = "boundary"
    else:
        mode = "random"

    if mode == "boundary":
        boundary = compute_boundary_map(mask01, ksize=3)
        ys, xs = np.where(boundary > 0)
        if len(xs) < 10:
            mode = "foreground"

    if mode == "foreground":
        ys, xs = np.where(mask01 > 0)
        if len(xs) < 10:
            mode = "random"

    for _ in range(max_tries):
        if mode == "random":
            x = int(random.randint(0, w - patch))
            y = int(random.randint(0, h - patch))
            return x, y, "random"

        idx = int(random.randint(0, len(xs) - 1))
        cx, cy = int(xs[idx]), int(ys[idx])

        x = int(np.clip(cx - patch // 2, 0, w - patch))
        y = int(np.clip(cy - patch // 2, 0, h - patch))

        crop = mask01[y : y + patch, x : x + patch]
        fg_frac = float((crop > 0).mean())
        if mode != "foreground" or fg_frac >= min_fg_frac:
            return x, y, mode

    x = int(random.randint(0, w - patch))
    y = int(random.randint(0, h - patch))
    return x, y, "fallback"

