#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/cli/train_cli.py 
#  Purpose       : Train CLI
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================
"""
Description:
    Training entry point for CiproSeg.

    Responsibilities:
      - Parse CLI args
      - Load config (YAML)
      - Setup logging
      - Seed RNGs (for reproducibility)
      - Run Engine.fit()
"""

from __future__ import annotations

import argparse
import sys
from typing import Any, Dict

from ..core.engine import Engine
from ..utils.config import load_config
from ..utils.logger import setup_logging, get_logger
from ..utils.seed import seed_everything


def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="CiproSeg training CLI")
    p.add_argument("--config", type=str, required=True, help="Path to YAML config.")
    # Optional overrides (handy when testing quickly)
    p.add_argument("--seed", type=int, default=None, help="Override trainer.seed.")
    p.add_argument("--cpu", action="store_true", help="Force CPU (overrides trainer.cpu).")
    return p


def _apply_overrides(cfg: Dict[str, Any], args: argparse.Namespace) -> Dict[str, Any]:
    # Keep overrides minimal and explicit to avoid confusing runs.
    cfg = dict(cfg)
    cfg.setdefault("trainer", {})
    cfg["trainer"] = dict(cfg["trainer"])

    if args.seed is not None:
        cfg["trainer"]["seed"] = int(args.seed)
    if args.cpu:
        cfg["trainer"]["cpu"] = True

    return cfg


def main() -> int:
    args = build_argparser().parse_args()
    cfg = load_config(args.config)
    cfg = _apply_overrides(cfg, args)

    # logging first (so everything prints consistently)
    setup_logging(cfg)
    logger = get_logger(cfg)

    # reproducibility (fold seeds derive from this)
    tcfg = cfg.get("trainer", {}) or {}
    seed = int(tcfg.get("seed", 42))
    deterministic = bool(tcfg.get("deterministic", False))
    benchmark = bool(tcfg.get("benchmark", True))
    seed_everything(seed, deterministic=deterministic, benchmark=benchmark)

    logger.info(f"[CiproSeg] Config: {args.config}")
    logger.info(f"[CiproSeg] seed={seed} deterministic={deterministic} benchmark={benchmark}")

    engine = Engine(cfg)
    engine.fit()

    logger.info("[CiproSeg] Training completed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
