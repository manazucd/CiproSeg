#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/optim/schedulers.py
#  Purpose       : Schedular
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple
import torch


@dataclass(frozen=True)
class SchedulerBundle:
    scheduler: torch.optim.lr_scheduler._LRScheduler
    interval: str  # "step" or "epoch"


def build_scheduler(
    optimizer: torch.optim.Optimizer,
    cfg: Dict[str, Any],
    *,
    steps_per_epoch: Optional[int] = None,
    epochs: Optional[int] = None,
) -> Optional[SchedulerBundle]:
    """
    Config expected (example):

    sched:
      name: cosine
      tmax: 40
      eta_min: 0.0

    or:

    sched:
      name: onecycle
      max_lr: 1e-3
      pct_start: 0.1
      div_factor: 25.0
      final_div_factor: 1e4
    """
    scfg = cfg.get("sched", {}) or {}
    name = str(scfg.get("name", "none")).lower()

    if name in ("none", "", "null"):
        return None

    if name == "cosine":
        # epoch-based cosine
        tmax = int(scfg.get("tmax", epochs if epochs is not None else 100))
        eta_min = float(scfg.get("eta_min", 0.0))
        sched = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=tmax, eta_min=eta_min)
        return SchedulerBundle(scheduler=sched, interval="epoch")

    if name == "step":
        step_size = int(scfg.get("step_size", 10))
        gamma = float(scfg.get("gamma", 0.1))
        sched = torch.optim.lr_scheduler.StepLR(optimizer, step_size=step_size, gamma=gamma)
        return SchedulerBundle(scheduler=sched, interval="epoch")

    if name == "onecycle":
        # step-based schedule: needs steps_per_epoch and epochs
        if steps_per_epoch is None or epochs is None:
            raise ValueError("OneCycleLR requires steps_per_epoch and epochs.")
        max_lr = float(scfg.get("max_lr", 1e-3))
        pct_start = float(scfg.get("pct_start", 0.1))
        div_factor = float(scfg.get("div_factor", 25.0))
        final_div_factor = float(scfg.get("final_div_factor", 1e4))

        sched = torch.optim.lr_scheduler.OneCycleLR(
            optimizer,
            max_lr=max_lr,
            epochs=int(epochs),
            steps_per_epoch=int(steps_per_epoch),
            pct_start=pct_start,
            div_factor=div_factor,
            final_div_factor=final_div_factor,
        )
        return SchedulerBundle(scheduler=sched, interval="step")

    raise ValueError(f"Unknown scheduler: {name}")
