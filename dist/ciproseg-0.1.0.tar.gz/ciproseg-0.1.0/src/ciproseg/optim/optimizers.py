#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Apache-2.0
# =======================================================================
#  Project       : CiproSeg - LOSO U-Net Segmentation Framework
#  File          : src/ciproseg/optim/optimizers.py
#  Purpose       : Optimiser
#
#  Copyright (c) 2026 Manaz Kaleel, Team NexoraLab
#  Authors       : Manaz Kaleel <manaz.ucd@gmail.com>, Team NexoraLab
#
#  Created on    : 2026-02-15
#  Last modified : 2026-02-16
#  Version       : 0.1.0
#  License       : Apache-2.0
#  Repository    : https://github.com/manazucd/CiproSeg
# =======================================================================

from __future__ import annotations

from typing import Any, Dict, Iterable, Optional, Tuple
import torch
import torch.nn as nn


def _split_decay_params(
    model: nn.Module,
    weight_decay: float,
) -> list[dict]:
    """
    Professional default: do NOT apply weight decay to:
      - biases
      - BatchNorm / LayerNorm parameters
    """
    decay: list[torch.Tensor] = []
    no_decay: list[torch.Tensor] = []

    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue

        is_bias = name.endswith(".bias")
        is_norm = (
            "bn" in name.lower()
            or "batchnorm" in name.lower()
            or "layernorm" in name.lower()
            or "ln" in name.lower()
        )

        if is_bias or is_norm:
            no_decay.append(p)
        else:
            decay.append(p)

    return [
        {"params": decay, "weight_decay": float(weight_decay)},
        {"params": no_decay, "weight_decay": 0.0},
    ]


def build_optimizer(
    params_or_model: Any,
    cfg: Dict[str, Any],
) -> torch.optim.Optimizer:
    """
    Config expected (example):

    optim:
      name: adamw
      lr: 1e-4
      weight_decay: 1e-4
      betas: [0.9, 0.999]
      eps: 1e-8
      momentum: 0.9  # for sgd
    """
    ocfg = cfg.get("optim", {}) or {}
    name = str(ocfg.get("name", "adam")).lower()
    lr = float(ocfg.get("lr", 1e-3))
    wd = float(ocfg.get("weight_decay", 0.0))

    betas = tuple(ocfg.get("betas", (0.9, 0.999)))
    eps = float(ocfg.get("eps", 1e-8))
    momentum = float(ocfg.get("momentum", 0.9))

    # Allow passing either model (preferred) or parameters iterable
    if isinstance(params_or_model, nn.Module):
        model = params_or_model
        param_groups = _split_decay_params(model, weight_decay=wd) if wd > 0 else model.parameters()
    else:
        model = None
        param_groups = params_or_model  # assume iterable of params

    if name == "adam":
        return torch.optim.Adam(param_groups, lr=lr, betas=betas, eps=eps, weight_decay=wd if model is None else 0.0)

    if name == "adamw":
        return torch.optim.AdamW(param_groups, lr=lr, betas=betas, eps=eps, weight_decay=wd if model is None else 0.0)

    if name == "sgd":
        return torch.optim.SGD(param_groups, lr=lr, momentum=momentum, nesterov=True, weight_decay=wd if model is None else 0.0)

    raise ValueError(f"Unknown optimizer: {name}")
