# tests/test_model.py
from __future__ import annotations

import torch

from ciproseg.models.unet import UNet


def test_unet_forward_shape_logits() -> None:
    model = UNet(in_channels=1, out_channels=1, base_channels=16)  # smaller for speed
    x = torch.randn(2, 1, 128, 128)  # divisible by 16
    logits = model(x)

    assert logits.shape == (2, 1, 128, 128)
    # logits should be raw (not sigmoid)
    # (not a strict proof, but we can check it isn't constrained to [0,1])
    assert (logits.min() < 0.0) or (logits.max() > 1.0)


def test_unet_num_params_positive() -> None:
    model = UNet(in_channels=1, out_channels=1, base_channels=16)
    n = model.get_num_params()
    assert isinstance(n, int)
    assert n > 0
