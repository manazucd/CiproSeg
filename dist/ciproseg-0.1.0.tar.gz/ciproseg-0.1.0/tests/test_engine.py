# tests/test_engine.py
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

import pytest

from ciproseg.core.engine import Engine


class _DummyTrainer:
    def __init__(self, cfg: Dict[str, Any], datamodule: Any = None, hooks: Any = None):
        self.cfg = cfg
        self.best_metric = 0.42
        self.last_metrics = {"dice": 0.9, "iou": 0.8, "precision": 0.85, "recall": 0.88}

    def train(self, start_state=None) -> None:
        # no-op “training”
        return


class _DummyEvaluator:
    def __init__(self, cfg: Dict[str, Any], datamodule: Any = None, hooks: Any = None):
        self.cfg = cfg

    def evaluate(self) -> Dict[str, float]:
        return {"num_series": 1.0, "num_frames": 3.0}

    def test(self) -> Dict[str, float]:
        return {"num_series": 1.0, "num_frames": 3.0}


def test_engine_fit_and_evaluate_smoke(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    # Patch Engine's imported Trainer/Evaluator classes
    monkeypatch.setattr("ciproseg.core.engine.Trainer", _DummyTrainer)
    monkeypatch.setattr("ciproseg.core.engine.Evaluator", _DummyEvaluator)

    cfg = {
        "trainer": {"output_dir": str(tmp_path)},
        "dataset": {"root": str(tmp_path)},  # not used by dummy trainer/evaluator
    }

    eng = Engine(cfg)
    eng.fit()

    # run_summary should be written by Checkpointer
    assert (tmp_path / "run_summary.pt").exists()

    metrics = eng.evaluate()
    assert isinstance(metrics, dict)
    assert "num_series" in metrics
