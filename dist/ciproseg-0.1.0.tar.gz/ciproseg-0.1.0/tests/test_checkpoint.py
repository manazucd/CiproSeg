# tests/test_checkpoint.py
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

import torch

from ciproseg.utils.checkpoint import Checkpointer


class _DummyTrainer:
    def __init__(self):
        self.best_metric = 0.123
        self.last_metrics = {"dice": 0.9, "iou": 0.8, "precision": 0.85, "recall": 0.88}


def test_checkpointer_saves_run_summary(tmp_path: Path) -> None:
    cfg: Dict[str, Any] = {"trainer": {"output_dir": str(tmp_path)}}
    ckpt = Checkpointer(cfg)

    tr = _DummyTrainer()
    ckpt.save_if_best(tr, metric_value=tr.best_metric)

    pt_path = tmp_path / "run_summary.pt"
    js_path = tmp_path / "run_summary.json"

    assert pt_path.exists(), "Expected run_summary.pt to be written"
    assert js_path.exists(), "Expected run_summary.json to be written"

    state = torch.load(pt_path, map_location="cpu")
    assert "best_metric" in state
    assert "last_metrics" in state
    assert state["last_metrics"]["dice"] == tr.last_metrics["dice"]

    with open(js_path, "r", encoding="utf-8") as f:
        j = json.load(f)
    assert "best_metric" in j
    assert "last_metrics" in j
    assert abs(float(j["best_metric"]) - tr.best_metric) < 1e-12


def test_checkpointer_maybe_load_when_missing(tmp_path: Path) -> None:
    cfg: Dict[str, Any] = {"trainer": {"output_dir": str(tmp_path)}}
    ckpt = Checkpointer(cfg)

    tr = _DummyTrainer()
    assert ckpt.maybe_load(tr) is None
