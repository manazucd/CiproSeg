# tests/test_loss.py
from __future__ import annotations

import torch
import torch.nn as nn


def test_bce_with_logits_loss_backward() -> None:
    criterion = nn.BCEWithLogitsLoss()
    logits = torch.randn(4, 1, 64, 64, requires_grad=True)
    target = (torch.rand(4, 1, 64, 64) > 0.5).float()

    loss = criterion(logits, target)
    assert loss.ndim == 0
    loss.backward()
    assert logits.grad is not None
    assert torch.isfinite(logits.grad).all()
